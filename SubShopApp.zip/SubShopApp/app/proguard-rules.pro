# Add project specific ProGuard rules here.
# This app ships with minification disabled by default (see build.gradle.kts),
# so these rules only take effect if you turn isMinifyEnabled on.

# Keep the WebView JavaScript interface methods (if any are added later).
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
