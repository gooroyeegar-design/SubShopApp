/* ==========================================================================
   Sub Shop — shop.js
   Page-specific logic for index.html:
     - Sign-in gate
     - Tab switching (Shop / Settings)
     - Dashboard rendering (subscriber count, progress bar, stats)
     - Shop grid rendering (locked/unlocked/claimed cards)
     - Claim confirmation modal
     - Settings form (channel connect, Google client ID, dark mode, sign out)
   ========================================================================== */

(function () {

  // Item pending confirmation in the claim modal.
  let pendingClaimItem = null;

  /* ------------------------------------------------------------------
     GATE: decide whether to show the sign-in screen or the app itself.
     ------------------------------------------------------------------ */
  function initGate() {
    const gate = document.getElementById('gate-screen');
    const app = document.getElementById('app-screen');

    if (SubShop.isAuthenticated()) {
      gate.classList.add('hidden');
      app.classList.remove('hidden');
      boot();
    } else {
      gate.classList.remove('hidden');
      app.classList.add('hidden');
      SubShop.renderGoogleButton();
      document.getElementById('guest-btn').addEventListener('click', () => {
        SubShop.storage.set(SubShop.KEYS.GUEST, true);
        window.location.reload();
      });
    }
  }

  /* ------------------------------------------------------------------
     BOOT: runs once the person is inside the app.
     ------------------------------------------------------------------ */
  function boot() {
    renderUserAvatar();
    initTabs();
    initSettingsForm();
    initClaimModal();

    // Render immediately from cache, then kick off a live refresh + polling.
    renderDashboardAndShop();
    refreshChannel();
    SubShop.startAutoRefresh(() => renderDashboardAndShop());

    document.getElementById('refresh-now-btn').addEventListener('click', refreshChannel);
    document.getElementById('signout-btn').addEventListener('click', () => {
      SubShop.storage.remove(SubShop.KEYS.GUEST);
      SubShop.signOut();
    });
  }

  async function refreshChannel() {
    const channel = await SubShop.fetchSubscriberCount();
    if (channel) {
      renderDashboardAndShop();
      SubShop.toast('Subscriber count updated!', '🔄');
    }
  }

  /* ------------------------------------------------------------------
     USER AVATAR (header)
     ------------------------------------------------------------------ */
  function renderUserAvatar() {
    const user = SubShop.getGoogleUser();
    const avatar = document.getElementById('user-avatar');
    if (user && user.picture) {
      avatar.src = user.picture;
      avatar.classList.remove('hidden');
    }
  }

  /* ------------------------------------------------------------------
     TABS (Shop / Settings)
     ------------------------------------------------------------------ */
  function initTabs() {
    const navItems = document.querySelectorAll('.nav-item[data-tab]');
    navItems.forEach(btn => {
      btn.addEventListener('click', () => {
        navItems.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        document.querySelectorAll('main > section').forEach(s => s.classList.add('hidden'));
        document.getElementById(btn.dataset.tab).classList.remove('hidden');
        if (btn.dataset.tab === 'tab-settings') renderSettingsTab();
      });
    });
  }

  /* ------------------------------------------------------------------
     DASHBOARD + SHOP RENDERING
     ------------------------------------------------------------------ */
  function renderDashboardAndShop() {
    const channel = SubShop.getChannel();
    const items = SubShop.getItems().slice().sort((a, b) => a.cost - b.cost);
    const claims = SubShop.getClaims();
    const subs = channel && channel.subscriberCount !== null ? channel.subscriberCount : 0;

    // --- Channel name in dashboard header ---
    const channelNameEl = document.getElementById('channel-name');
    channelNameEl.textContent = channel ? channel.title : 'No channel connected';

    // --- Subscriber count ---
    const subCountEl = document.getElementById('sub-count');
    const displayValue = channel
      ? (channel.hiddenSubscriberCount ? 'Hidden' : SubShop.formatNumber(subs))
      : '—';
    if (subCountEl.textContent !== displayValue) {
      subCountEl.textContent = displayValue;
      subCountEl.classList.add('pop');
      setTimeout(() => subCountEl.classList.remove('pop'), 400);
    }

    // --- Progress bar toward next locked item ---
    const lockedItems = items.filter(i => i.cost > subs);
    const nextTarget = lockedItems.length > 0 ? lockedItems[0] : null;
    const progressFill = document.getElementById('progress-fill');
    const progressCurrent = document.getElementById('progress-current');
    const progressTarget = document.getElementById('progress-target');

    progressCurrent.textContent = `${SubShop.formatNumber(subs)} subs`;
    if (nextTarget) {
      const pct = Math.min(100, Math.round((subs / nextTarget.cost) * 100));
      progressFill.style.width = pct + '%';
      progressTarget.textContent = `${nextTarget.name} (${SubShop.formatNumber(nextTarget.cost)})`;
    } else if (items.length > 0) {
      progressFill.style.width = '100%';
      progressTarget.textContent = 'Everything unlocked! 🎉';
    } else {
      progressFill.style.width = '0%';
      progressTarget.textContent = 'Add rewards in Admin';
    }

    // --- Stat boxes ---
    document.getElementById('stat-subs').textContent = SubShop.formatNumber(subs);
    document.getElementById('stat-unlocked').textContent = items.filter(i => i.cost <= subs).length;
    document.getElementById('stat-claimed').textContent = claims.length;

    // --- Shop grid ---
    renderShopGrid(items, claims, subs);
  }

  function renderShopGrid(items, claims, subs) {
    const grid = document.getElementById('shop-grid');
    const empty = document.getElementById('shop-empty');

    if (items.length === 0) {
      grid.innerHTML = '';
      empty.classList.remove('hidden');
      return;
    }
    empty.classList.add('hidden');

    grid.innerHTML = items.map(item => {
      const unlocked = item.cost <= subs;
      const claimed = claims.some(c => c.itemId === item.id);

      const imageHtml = item.image
        ? `<img src="${item.image}" alt="${escapeHtml(item.name)}" />`
        : `<div class="placeholder-icon">🎁</div>`;

      const lockBadge = !unlocked
        ? `<span class="lock-badge">🔒 ${SubShop.formatNumber(item.cost - subs)} to go</span>`
        : '';
      const claimedBadge = claimed ? `<span class="claimed-badge">✓ Claimed</span>` : '';
      const lockCenter = !unlocked ? `<div class="lock-icon-center">🔒</div>` : '';

      let btnHtml;
      if (claimed) {
        btnHtml = `<button class="item-claim-btn claimed" disabled>✓ Claimed</button>`;
      } else if (unlocked) {
        btnHtml = `<button class="item-claim-btn" data-claim-id="${item.id}">Claim Reward</button>`;
      } else {
        btnHtml = `<button class="item-claim-btn" disabled>Locked</button>`;
      }

      return `
        <div class="item-card ${unlocked ? '' : 'locked'}">
          <div class="item-image-wrap">
            ${imageHtml}
            ${lockBadge}
            ${claimedBadge}
            ${lockCenter}
          </div>
          <div class="item-body">
            <div class="item-name">${escapeHtml(item.name)}</div>
            <div class="item-desc">${escapeHtml(item.description || '')}</div>
            <div class="item-cost">🪙 ${SubShop.formatNumber(item.cost)} subs</div>
            ${btnHtml}
          </div>
        </div>
      `;
    }).join('');

    // Wire up claim buttons.
    grid.querySelectorAll('[data-claim-id]').forEach(btn => {
      btn.addEventListener('click', () => openClaimModal(btn.dataset.claimId));
    });
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
  }

  /* ------------------------------------------------------------------
     CLAIM CONFIRMATION MODAL
     ------------------------------------------------------------------ */
  function initClaimModal() {
    document.getElementById('claim-cancel-btn').addEventListener('click', closeClaimModal);
    document.getElementById('claim-confirm-btn').addEventListener('click', confirmClaim);
    document.getElementById('claim-modal').addEventListener('click', (e) => {
      if (e.target.id === 'claim-modal') closeClaimModal();
    });
  }

  function openClaimModal(itemId) {
    const item = SubShop.getItems().find(i => i.id === itemId);
    if (!item) return;
    pendingClaimItem = item;
    document.getElementById('claim-modal-title').textContent = `Claim "${item.name}"?`;
    document.getElementById('claim-modal-desc').textContent =
      `This marks the reward as claimed. Your ${SubShop.formatNumber(item.cost)} subscriber requirement stays exactly the same — nothing is deducted.`;
    document.getElementById('claim-modal').classList.add('open');
  }

  function closeClaimModal() {
    document.getElementById('claim-modal').classList.remove('open');
    pendingClaimItem = null;
  }

  function confirmClaim() {
    if (!pendingClaimItem) return;
    SubShop.claimItem(pendingClaimItem.id);
    SubShop.toast(`"${pendingClaimItem.name}" claimed!`, '🎉');
    closeClaimModal();
    renderDashboardAndShop();
  }

  /* ------------------------------------------------------------------
     SETTINGS TAB
     ------------------------------------------------------------------ */
  function renderSettingsTab() {
    // Account card
    const user = SubShop.getGoogleUser();
    const accountCard = document.getElementById('account-card');
    if (user) {
      accountCard.innerHTML = `
        <div class="channel-connected">
          <img src="${user.picture}" alt="${escapeHtml(user.name)}" />
          <div>
            <div class="name">${escapeHtml(user.name)}</div>
            <div class="subs">${escapeHtml(user.email)}</div>
          </div>
        </div>`;
    } else {
      accountCard.innerHTML = `<p>You're browsing as a <b>Guest</b>. Sign in with Google from the Settings below to link an account.</p>`;
    }

    // Channel status + prefilled fields
    const config = SubShop.getConfig();
    document.getElementById('input-channel-id').value = config.channelId || '';
    document.getElementById('input-api-key').value = config.apiKey || '';
    document.getElementById('input-google-client').value = config.googleClientId || '';

    const channel = SubShop.getChannel();
    const statusEl = document.getElementById('channel-status');
    if (channel) {
      statusEl.innerHTML = `
        <div class="channel-connected" style="margin-bottom:12px;">
          <img src="${channel.thumbnail}" alt="${escapeHtml(channel.title)}" />
          <div>
            <div class="name">${escapeHtml(channel.title)}</div>
            <div class="subs">${channel.hiddenSubscriberCount ? 'Subscriber count is hidden' : SubShop.formatNumber(channel.subscriberCount) + ' subscribers'}</div>
          </div>
        </div>`;
    } else {
      statusEl.innerHTML = `<p>Connect your channel to automatically read your live subscriber count.</p>`;
    }

    // Dark mode toggle state
    const toggle = document.getElementById('dark-mode-toggle');
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    toggle.classList.toggle('on', isDark);
  }

  function initSettingsForm() {
    document.getElementById('save-channel-btn').addEventListener('click', async () => {
      const channelId = document.getElementById('input-channel-id').value.trim();
      const apiKey = document.getElementById('input-api-key').value.trim();
      if (!channelId || !apiKey) {
        SubShop.toast('Enter both a Channel ID and API Key.', '⚠️');
        return;
      }
      const config = SubShop.getConfig();
      config.channelId = channelId;
      config.apiKey = apiKey;
      SubShop.saveConfig(config);

      const btn = document.getElementById('save-channel-btn');
      const originalText = btn.innerHTML;
      btn.innerHTML = `<span class="spinner"></span> Connecting...`;
      btn.disabled = true;

      const channel = await SubShop.fetchSubscriberCount();

      btn.innerHTML = originalText;
      btn.disabled = false;

      if (channel) {
        SubShop.toast('Channel connected!', '✅');
        renderSettingsTab();
        renderDashboardAndShop();
      }
    });

    document.getElementById('save-google-client-btn').addEventListener('click', () => {
      const clientId = document.getElementById('input-google-client').value.trim();
      const config = SubShop.getConfig();
      config.googleClientId = clientId;
      SubShop.saveConfig(config);
      SubShop.toast('Google Client ID saved!', '✅');
    });

    document.getElementById('dark-mode-toggle').addEventListener('click', () => {
      SubShop.toggleTheme();
      renderSettingsTab();
    });
  }

  /* ------------------------------------------------------------------
     INIT
     ------------------------------------------------------------------ */
  document.addEventListener('DOMContentLoaded', initGate);

})();
