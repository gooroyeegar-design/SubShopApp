/* ==========================================================================
   Sub Shop — admin.js
   Page-specific logic for admin.html:
     - Auth guard (redirects to index.html if not signed in / guest)
     - Render list of items
     - Add / Edit modal (name, cost, description, image upload)
     - Delete confirmation modal
   All data is written straight to localStorage via the SubShop.* helpers
   defined in app.js, so the Shop page picks up changes instantly on its
   next render.
   ========================================================================== */

(function () {

  let editingItemId = null;   // null = "add" mode, otherwise "edit" mode
  let pendingDeleteId = null;
  let currentImageData = '';  // base64 data URL of the selected image

  /* ------------------------------------------------------------------
     AUTH GUARD
     ------------------------------------------------------------------ */
  function guard() {
    if (!SubShop.isAuthenticated()) {
      window.location.href = 'index.html';
      return false;
    }
    return true;
  }

  /* ------------------------------------------------------------------
     RENDER ITEM LIST
     ------------------------------------------------------------------ */
  function renderList() {
    const items = SubShop.getItems().slice().sort((a, b) => a.cost - b.cost);
    const list = document.getElementById('admin-list');
    const empty = document.getElementById('admin-empty');

    if (items.length === 0) {
      list.innerHTML = '';
      empty.classList.remove('hidden');
      return;
    }
    empty.classList.add('hidden');

    list.innerHTML = items.map(item => {
      const thumb = item.image
        ? `<img class="thumb" src="${item.image}" alt="${escapeHtml(item.name)}" />`
        : `<div class="thumb">🎁</div>`;

      return `
        <div class="admin-list-item">
          ${thumb}
          <div class="info">
            <h4>${escapeHtml(item.name)}</h4>
            <p>${escapeHtml(item.description || 'No description')}</p>
            <div class="price-tag">🪙 ${SubShop.formatNumber(item.cost)} subs</div>
          </div>
          <div class="actions">
            <button class="icon-action" data-edit="${item.id}" title="Edit">✏️</button>
            <button class="icon-action danger" data-delete="${item.id}" title="Delete">🗑️</button>
          </div>
        </div>`;
    }).join('');

    list.querySelectorAll('[data-edit]').forEach(btn =>
      btn.addEventListener('click', () => openItemModal(btn.dataset.edit)));
    list.querySelectorAll('[data-delete]').forEach(btn =>
      btn.addEventListener('click', () => openDeleteModal(btn.dataset.delete)));
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
  }

  /* ------------------------------------------------------------------
     ADD / EDIT MODAL
     ------------------------------------------------------------------ */
  function openItemModal(itemId = null) {
    editingItemId = itemId;
    const title = document.getElementById('item-modal-title');
    const nameInput = document.getElementById('input-item-name');
    const costInput = document.getElementById('input-item-cost');
    const descInput = document.getElementById('input-item-desc');
    const preview = document.getElementById('image-preview');
    const placeholder = document.getElementById('image-preview-placeholder');

    if (itemId) {
      const item = SubShop.getItems().find(i => i.id === itemId);
      if (!item) return;
      title.textContent = 'Edit Item';
      nameInput.value = item.name;
      costInput.value = item.cost;
      descInput.value = item.description || '';
      currentImageData = item.image || '';
    } else {
      title.textContent = 'Add Item';
      nameInput.value = '';
      costInput.value = '';
      descInput.value = '';
      currentImageData = '';
    }

    updateImagePreview();
    document.getElementById('item-modal').classList.add('open');
    setTimeout(() => nameInput.focus(), 300);
  }

  function updateImagePreview() {
    const preview = document.getElementById('image-preview');
    const placeholder = document.getElementById('image-preview-placeholder');
    if (currentImageData) {
      preview.src = currentImageData;
      preview.classList.remove('hidden');
      placeholder.classList.add('hidden');
    } else {
      preview.classList.add('hidden');
      placeholder.classList.remove('hidden');
    }
  }

  function closeItemModal() {
    document.getElementById('item-modal').classList.remove('open');
    editingItemId = null;
    currentImageData = '';
    document.getElementById('input-item-image').value = '';
  }

  function initItemModal() {
    document.getElementById('add-item-btn').addEventListener('click', () => openItemModal());
    document.getElementById('item-modal-close').addEventListener('click', closeItemModal);
    document.getElementById('item-cancel-btn').addEventListener('click', closeItemModal);
    document.getElementById('item-modal').addEventListener('click', (e) => {
      if (e.target.id === 'item-modal') closeItemModal();
    });

    // Image upload: read the file as a base64 data URL so it can be stored
    // directly in localStorage (no backend / file server needed).
    document.getElementById('input-item-image').addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      if (file.size > 1.5 * 1024 * 1024) {
        SubShop.toast('Please choose an image under 1.5MB.', '⚠️');
        e.target.value = '';
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        currentImageData = reader.result;
        updateImagePreview();
      };
      reader.readAsDataURL(file);
    });

    document.getElementById('item-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('input-item-name').value.trim();
      const cost = parseInt(document.getElementById('input-item-cost').value, 10);
      const description = document.getElementById('input-item-desc').value.trim();

      if (!name || isNaN(cost) || cost < 0) {
        SubShop.toast('Please enter a valid name and cost.', '⚠️');
        return;
      }

      const payload = { name, cost, description, image: currentImageData };

      if (editingItemId) {
        SubShop.updateItem(editingItemId, payload);
        SubShop.toast('Item updated!', '✅');
      } else {
        SubShop.addItem(payload);
        SubShop.toast('Item added!', '✅');
      }

      closeItemModal();
      renderList();
    });
  }

  /* ------------------------------------------------------------------
     DELETE MODAL
     ------------------------------------------------------------------ */
  function openDeleteModal(itemId) {
    const item = SubShop.getItems().find(i => i.id === itemId);
    if (!item) return;
    pendingDeleteId = itemId;
    document.getElementById('delete-modal-desc').textContent =
      `Delete "${item.name}"? This can't be undone.`;
    document.getElementById('delete-modal').classList.add('open');
  }

  function closeDeleteModal() {
    document.getElementById('delete-modal').classList.remove('open');
    pendingDeleteId = null;
  }

  function initDeleteModal() {
    document.getElementById('delete-cancel-btn').addEventListener('click', closeDeleteModal);
    document.getElementById('delete-modal').addEventListener('click', (e) => {
      if (e.target.id === 'delete-modal') closeDeleteModal();
    });
    document.getElementById('delete-confirm-btn').addEventListener('click', () => {
      if (!pendingDeleteId) return;
      SubShop.deleteItem(pendingDeleteId);
      SubShop.toast('Item deleted.', '🗑️');
      closeDeleteModal();
      renderList();
    });
  }

  /* ------------------------------------------------------------------
     INIT
     ------------------------------------------------------------------ */
  document.addEventListener('DOMContentLoaded', () => {
    if (!guard()) return;
    renderList();
    initItemModal();
    initDeleteModal();
  });

})();
