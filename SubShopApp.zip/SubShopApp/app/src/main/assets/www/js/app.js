/* ==========================================================================
   Sub Shop — app.js
   Shared core module loaded on every page (index.html + admin.html).
   Responsibilities:
     - localStorage helpers (single source of truth for all app data)
     - Theme (dark/light) handling
     - Toast notifications
     - Google Sign-In (Google Identity Services)
     - YouTube Data API integration (fetch + auto-refresh subscriber count)
     - Service worker registration
   Every other script (shop.js, admin.js) relies on the `SubShop` namespace
   defined here.
   ========================================================================== */

// Everything lives under one global namespace so we never pollute `window`
// with loose variables across the multiple <script> files.
const SubShop = {};

/* --------------------------------------------------------------------------
   1. STORAGE LAYER
   All persisted data lives in localStorage under these keys. Using a single
   namespace object keeps read/write logic in one place so both the Shop
   page and the Admin page always stay in sync.
   -------------------------------------------------------------------------- */
SubShop.KEYS = {
  THEME: 'subshop_theme',
  ITEMS: 'subshop_items',
  CLAIMS: 'subshop_claims',
  CHANNEL: 'subshop_channel',
  CONFIG: 'subshop_config',       // { apiKey, channelId, googleClientId }
  GOOGLE_USER: 'subshop_google_user',
  GUEST: 'subshop_guest'
};

// Generic JSON get/set so callers never touch JSON.parse/stringify directly.
SubShop.storage = {
  get(key, fallback = null) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (err) {
      console.error(`[SubShop] Failed to read "${key}" from storage`, err);
      return fallback;
    }
  },
  set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (err) {
      console.error(`[SubShop] Failed to write "${key}" to storage`, err);
      return false;
    }
  },
  remove(key) {
    localStorage.removeItem(key);
  }
};

/* --------------------------------------------------------------------------
   2. SAMPLE DATA
   Seeded only the very first time the app runs (i.e. when no items exist
   yet in localStorage). The user is free to edit/delete every one of these
   from the Admin page — nothing is hardcoded into the shop logic itself.
   -------------------------------------------------------------------------- */
SubShop.SAMPLE_ITEMS = [
  {
    id: 'sample-1',
    name: 'Shoutout in a Video',
    description: 'Get your name or channel shouted out in an upcoming upload.',
    cost: 100,
    image: '',
    createdAt: Date.now()
  },
  {
    id: 'sample-2',
    name: 'Pick the Next Topic',
    description: 'You choose what the next video is about.',
    cost: 500,
    image: '',
    createdAt: Date.now()
  },
  {
    id: 'sample-3',
    name: 'Custom Thank-You Sticker Pack',
    description: 'A digital sticker pack designed just to say thanks.',
    cost: 1000,
    image: '',
    createdAt: Date.now()
  },
  {
    id: 'sample-4',
    name: '1-on-1 Video Call',
    description: 'A 15 minute video call with the creator.',
    cost: 5000,
    image: '',
    createdAt: Date.now()
  }
];

/* --------------------------------------------------------------------------
   3. ITEMS + CLAIMS DATA ACCESS
   -------------------------------------------------------------------------- */
SubShop.getItems = function () {
  let items = SubShop.storage.get(SubShop.KEYS.ITEMS);
  if (items === null) {
    // First run: seed sample items so the shop isn't empty.
    items = SubShop.SAMPLE_ITEMS;
    SubShop.storage.set(SubShop.KEYS.ITEMS, items);
  }
  return items;
};

SubShop.saveItems = function (items) {
  SubShop.storage.set(SubShop.KEYS.ITEMS, items);
};

SubShop.addItem = function (item) {
  const items = SubShop.getItems();
  item.id = 'item-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7);
  item.createdAt = Date.now();
  items.push(item);
  SubShop.saveItems(items);
  return item;
};

SubShop.updateItem = function (id, updates) {
  const items = SubShop.getItems();
  const idx = items.findIndex(i => i.id === id);
  if (idx === -1) return null;
  items[idx] = { ...items[idx], ...updates };
  SubShop.saveItems(items);
  return items[idx];
};

SubShop.deleteItem = function (id) {
  const items = SubShop.getItems().filter(i => i.id !== id);
  SubShop.saveItems(items);
  // Also clean up any claim record tied to the deleted item.
  const claims = SubShop.getClaims().filter(c => c.itemId !== id);
  SubShop.storage.set(SubShop.KEYS.CLAIMS, claims);
};

SubShop.getClaims = function () {
  return SubShop.storage.get(SubShop.KEYS.CLAIMS, []);
};

SubShop.isClaimed = function (itemId) {
  return SubShop.getClaims().some(c => c.itemId === itemId);
};

SubShop.claimItem = function (itemId) {
  const claims = SubShop.getClaims();
  if (claims.some(c => c.itemId === itemId)) return; // already claimed
  claims.push({ itemId, claimedAt: Date.now() });
  SubShop.storage.set(SubShop.KEYS.CLAIMS, claims);
};

SubShop.unclaimItem = function (itemId) {
  const claims = SubShop.getClaims().filter(c => c.itemId !== itemId);
  SubShop.storage.set(SubShop.KEYS.CLAIMS, claims);
};

/* --------------------------------------------------------------------------
   4. THEME (dark / light mode)
   -------------------------------------------------------------------------- */
SubShop.initTheme = function () {
  const saved = SubShop.storage.get(SubShop.KEYS.THEME);
  const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  const theme = saved || (prefersDark ? 'dark' : 'light');
  document.documentElement.setAttribute('data-theme', theme);
  SubShop.updateThemeIcon(theme);
};

SubShop.toggleTheme = function () {
  const current = document.documentElement.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  SubShop.storage.set(SubShop.KEYS.THEME, next);
  SubShop.updateThemeIcon(next);
};

SubShop.updateThemeIcon = function (theme) {
  const btn = document.getElementById('theme-toggle-btn');
  if (btn) btn.textContent = theme === 'dark' ? '☀️' : '🌙';
};

/* --------------------------------------------------------------------------
   5. TOAST NOTIFICATIONS
   Small non-blocking confirmation messages (e.g. "Item claimed!").
   -------------------------------------------------------------------------- */
SubShop.toast = function (message, icon = '✅') {
  let el = document.getElementById('toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'toast';
    el.className = 'toast';
    document.body.appendChild(el);
  }
  el.innerHTML = `<span>${icon}</span><span>${message}</span>`;
  el.classList.add('show');
  clearTimeout(SubShop._toastTimer);
  SubShop._toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
};

/* --------------------------------------------------------------------------
   6. CONFIG (API key / Channel ID / Google Client ID)
   Stored locally so the whole app works from a static GitHub Pages deploy
   with zero backend server.
   -------------------------------------------------------------------------- */
SubShop.getConfig = function () {
  return SubShop.storage.get(SubShop.KEYS.CONFIG, {
    apiKey: '',
    channelId: '',
    googleClientId: ''
  });
};

SubShop.saveConfig = function (config) {
  SubShop.storage.set(SubShop.KEYS.CONFIG, config);
};

/* --------------------------------------------------------------------------
   7. GOOGLE SIGN-IN
   Uses Google Identity Services (GIS) purely to authenticate *the person
   using the app* (shows their name/photo, gates the UI). This is separate
   from the YouTube Data API call below, which uses a simple API key +
   channel ID — no OAuth consent screen needed, which keeps a static,
   backend-less deployment simple.
   -------------------------------------------------------------------------- */
SubShop.getGoogleUser = function () {
  return SubShop.storage.get(SubShop.KEYS.GOOGLE_USER);
};

SubShop.isGuest = function () {
  return SubShop.storage.get(SubShop.KEYS.GUEST) === true;
};

// True once the person has either signed in with Google or chosen Guest Mode.
SubShop.isAuthenticated = function () {
  return !!SubShop.getGoogleUser() || SubShop.isGuest();
};

SubShop.signOut = function () {
  SubShop.storage.remove(SubShop.KEYS.GOOGLE_USER);
  if (window.google && google.accounts && google.accounts.id) {
    google.accounts.id.disableAutoSelect();
  }
  window.location.href = 'index.html';
};

// Decodes the JWT credential Google returns after a successful sign-in.
// (No server round-trip needed — we only need the profile fields for UI.)
SubShop.decodeJwt = function (token) {
  try {
    const base64 = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
    const json = decodeURIComponent(
      atob(base64)
        .split('')
        .map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );
    return JSON.parse(json);
  } catch (err) {
    console.error('[SubShop] Failed to decode Google credential', err);
    return null;
  }
};

// Called by the Google Identity Services library after successful sign-in.
// Must be attached to `window` because Google's script calls it directly.
window.handleGoogleSignIn = function (response) {
  const profile = SubShop.decodeJwt(response.credential);
  if (!profile) {
    SubShop.toast('Sign-in failed. Please try again.', '⚠️');
    return;
  }
  SubShop.storage.set(SubShop.KEYS.GOOGLE_USER, {
    name: profile.name,
    email: profile.email,
    picture: profile.picture
  });
  window.location.href = 'index.html';
};

// Renders the official Google Sign-In button inside #google-signin-btn.
SubShop.renderGoogleButton = function () {
  const container = document.getElementById('google-signin-btn');
  if (!container) return;
  const { googleClientId } = SubShop.getConfig();

  if (!googleClientId) {
    container.innerHTML = `
      <p style="font-size:13px;color:var(--text-secondary);max-width:280px;">
        Add your Google OAuth Client ID in <b>Settings</b> to enable Sign-In,
        or use Guest Mode below to explore the app first.
      </p>`;
    return;
  }

  if (!window.google || !google.accounts || !google.accounts.id) {
    // GIS script hasn't loaded yet (e.g. offline). Retry shortly.
    setTimeout(SubShop.renderGoogleButton, 500);
    return;
  }

  google.accounts.id.initialize({
    client_id: googleClientId,
    callback: window.handleGoogleSignIn
  });
  google.accounts.id.renderButton(container, {
    theme: document.documentElement.getAttribute('data-theme') === 'dark' ? 'filled_black' : 'outline',
    size: 'large',
    shape: 'pill',
    width: 260
  });
};

/* --------------------------------------------------------------------------
   8. YOUTUBE DATA API
   Fetches the public subscriber count for the configured channel using an
   API key (no OAuth needed for public statistics). Auto-refreshes on an
   interval and caches the last known value so the dashboard still renders
   instantly (and offline) on subsequent loads.
   -------------------------------------------------------------------------- */
SubShop.YT_REFRESH_MS = 5 * 60 * 1000; // auto-refresh every 5 minutes

SubShop.getChannel = function () {
  return SubShop.storage.get(SubShop.KEYS.CHANNEL);
};

SubShop.fetchSubscriberCount = async function ({ silent = false } = {}) {
  const { apiKey, channelId } = SubShop.getConfig();
  if (!apiKey || !channelId) {
    if (!silent) SubShop.toast('Connect a YouTube channel in Settings first.', '⚠️');
    return null;
  }

  const url = `https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&id=${encodeURIComponent(channelId)}&key=${encodeURIComponent(apiKey)}`;

  try {
    const res = await fetch(url);
    const data = await res.json();

    if (data.error) {
      throw new Error(data.error.message || 'YouTube API error');
    }
    if (!data.items || data.items.length === 0) {
      throw new Error('Channel not found. Double-check the Channel ID.');
    }

    const channelData = data.items[0];
    const channel = {
      id: channelData.id,
      title: channelData.snippet.title,
      thumbnail: channelData.snippet.thumbnails?.default?.url || '',
      // hiddenSubscriberCount is true if the creator has hidden their count publicly.
      subscriberCount: channelData.statistics.hiddenSubscriberCount
        ? null
        : parseInt(channelData.statistics.subscriberCount, 10),
      hiddenSubscriberCount: !!channelData.statistics.hiddenSubscriberCount,
      updatedAt: Date.now()
    };

    SubShop.storage.set(SubShop.KEYS.CHANNEL, channel);
    return channel;
  } catch (err) {
    console.error('[SubShop] YouTube fetch failed', err);
    if (!silent) SubShop.toast(err.message || 'Could not reach YouTube API.', '⚠️');
    return null;
  }
};

// Starts the periodic background refresh. Safe to call multiple times —
// it clears any existing interval first.
SubShop.startAutoRefresh = function (onUpdate) {
  if (SubShop._refreshInterval) clearInterval(SubShop._refreshInterval);
  SubShop._refreshInterval = setInterval(async () => {
    const channel = await SubShop.fetchSubscriberCount({ silent: true });
    if (channel && typeof onUpdate === 'function') onUpdate(channel);
  }, SubShop.YT_REFRESH_MS);
};

/* --------------------------------------------------------------------------
   9. SERVICE WORKER REGISTRATION (offline support + installability)
   -------------------------------------------------------------------------- */
SubShop.registerServiceWorker = function () {
  if (!('serviceWorker' in navigator)) return;
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('service-worker.js').catch(err => {
      console.error('[SubShop] Service worker registration failed', err);
    });
  });
};

/* --------------------------------------------------------------------------
   10. ONLINE / OFFLINE BANNER
   -------------------------------------------------------------------------- */
SubShop.initOfflineBanner = function () {
  const banner = document.getElementById('offline-banner');
  if (!banner) return;
  const update = () => banner.classList.toggle('show', !navigator.onLine);
  window.addEventListener('online', update);
  window.addEventListener('offline', update);
  update();
};

/* --------------------------------------------------------------------------
   11. SHARED FORMATTING HELPERS
   -------------------------------------------------------------------------- */
SubShop.formatNumber = function (num) {
  if (num === null || num === undefined) return '—';
  return num.toLocaleString('en-US');
};

/* --------------------------------------------------------------------------
   BOOTSTRAP
   Runs on every page load, before page-specific scripts execute.
   -------------------------------------------------------------------------- */
SubShop.initTheme();
SubShop.registerServiceWorker();
document.addEventListener('DOMContentLoaded', () => {
  SubShop.initOfflineBanner();
  const themeBtn = document.getElementById('theme-toggle-btn');
  if (themeBtn) themeBtn.addEventListener('click', SubShop.toggleTheme);
});
