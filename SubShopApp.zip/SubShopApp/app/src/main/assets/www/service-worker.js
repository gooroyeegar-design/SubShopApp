/* ==========================================================================
   Sub Shop — service-worker.js
   Provides offline support (cache-first app shell) and enables the
   "Add to Home Screen" install prompt on Android/Chrome.

   NOTE: All cached paths are relative (no leading "/") so this works
   correctly when deployed to a GitHub Pages *project* site, which is
   served from a sub-path like https://username.github.io/sub-shop/
   rather than the domain root.
   ========================================================================== */

// Bump this version string any time you change any cached file — it forces
// the browser to fetch fresh copies instead of serving stale ones.
const CACHE_NAME = 'sub-shop-cache-v1';

// The "app shell": everything needed for the app to boot while offline.
const APP_SHELL = [
  'index.html',
  'admin.html',
  'manifest.json',
  'css/style.css',
  'js/app.js',
  'js/shop.js',
  'js/admin.js',
  'icons/icon-192.png',
  'icons/icon-512.png',
  'icons/icon-maskable-192.png',
  'icons/icon-maskable-512.png',
  'icons/favicon.png'
];

/* --------------------------------------------------------------------
   INSTALL: pre-cache the app shell.
   -------------------------------------------------------------------- */
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

/* --------------------------------------------------------------------
   ACTIVATE: clean up old cache versions.
   -------------------------------------------------------------------- */
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter((key) => key !== CACHE_NAME)
            .map((key) => caches.delete(key))
      )
    ).then(() => self.clients.claim())
  );
});

/* --------------------------------------------------------------------
   FETCH strategy:
     - Same-origin requests (our own HTML/CSS/JS/icons): cache-first,
       falling back to network, and updating the cache in the background.
     - Cross-origin requests (YouTube Data API, Google Sign-In, fonts):
       network-only — we never want to serve stale subscriber counts or
       auth scripts from cache. The app already caches the *last known*
       subscriber count in localStorage for offline display.
   -------------------------------------------------------------------- */
self.addEventListener('fetch', (event) => {
  const requestUrl = new URL(event.request.url);
  const isSameOrigin = requestUrl.origin === self.location.origin;

  if (!isSameOrigin) {
    // Let the browser handle cross-origin requests normally.
    return;
  }

  // Only cache-handle GET requests.
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      const networkFetch = fetch(event.request)
        .then((networkResponse) => {
          // Stash a fresh copy for next time.
          if (networkResponse && networkResponse.status === 200) {
            const clone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          }
          return networkResponse;
        })
        .catch(() => cachedResponse); // offline: fall back to cache

      // Serve from cache immediately if we have it, otherwise wait on network.
      return cachedResponse || networkFetch;
    })
  );
});
